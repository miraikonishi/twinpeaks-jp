<?php
// You shall not pass!